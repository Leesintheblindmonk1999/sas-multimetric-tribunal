import json
import numpy as np
from sklearn.metrics import roc_auc_score

KAPPA_D = 0.56
KAPPA_R = 0.15

d = json.load(open("reports/pairs_conditions_1800_seed42.json", encoding="utf-8"))
r = d["resultados"]

# ── Merge con clave compuesta (suite, id) ─────────────────────────────
positivos = {(x["suite"], x["id"]): x for x in r if x["condicion"] == "A_B"}
negativos = {(x["suite"], x["id"]): x for x in r if x["condicion"] == "A_Ap"}

ids_comunes = sorted(set(positivos.keys()) & set(negativos.keys()))
print(f"IDs con ambas condiciones: {len(ids_comunes)}")
assert len(ids_comunes) == 1800, f"Se esperaba 1800, se obtuvieron {len(ids_comunes)}"

pos_final = np.array([positivos[k]["isi_final"] for k in ids_comunes])
neg_final = np.array([negativos[k]["isi_final"] for k in ids_comunes])
pos_avg   = np.array([positivos[k]["isi_avg"]   for k in ids_comunes])
neg_avg   = np.array([negativos[k]["isi_avg"]   for k in ids_comunes])

# ── Esquema multiplicativo (isi_final) con κD fijo ────────────────────
tp = int((pos_final < KAPPA_D).sum())
fn = int((pos_final >= KAPPA_D).sum())
fp = int((neg_final < KAPPA_D).sum())
tn = int((neg_final >= KAPPA_D).sum())
precision = tp / (tp + fp) if (tp + fp) else 0
recall = tp / (tp + fn) if (tp + fn) else 0
f1_mult = 2 * precision * recall / (precision + recall) if (precision + recall) else 0
auc_mult = roc_auc_score([1]*len(pos_final) + [0]*len(neg_final),
                          -np.concatenate([pos_final, neg_final]))

print(f"\nMultiplicativo (isi_final, κD={KAPPA_D}):")
print(f"  TP={tp}  FN={fn}  FP={fp}  TN={tn}")
print(f"  Precision={precision:.4f}  Recall={recall:.4f}  F1={f1_mult:.4f}")
print(f"  AUROC={auc_mult:.4f}")

# ── Esquema promedio (isi_avg) con barrido de umbral ──────────────────
print(f"\nPromedio (isi_avg), barrido de umbral:")
print(f"  {'umbral':>8} {'TP':>5} {'FN':>5} {'FP':>5} {'TN':>5} {'Prec':>8} {'Rec':>8} {'F1':>8}")

mejor_f1 = 0
mejor_umbral = None
umbrales_a_reportar = [0.10, 0.20, 0.30, 0.40, 0.50, 0.56, 0.60, 0.70, 0.80, 0.84, 0.90, 0.95]

for u in np.arange(0.02, 1.0, 0.01):
    tp_ = int((pos_avg < u).sum())
    fn_ = int((pos_avg >= u).sum())
    fp_ = int((neg_avg < u).sum())
    tn_ = int((neg_avg >= u).sum())
    prec = tp_ / (tp_ + fp_) if (tp_ + fp_) else 0
    rec  = tp_ / (tp_ + fn_) if (tp_ + fn_) else 0
    f1_  = 2 * prec * rec / (prec + rec) if (prec + rec) else 0
    if f1_ > mejor_f1:
        mejor_f1 = f1_
        mejor_umbral = u
    if round(u, 2) in umbrales_a_reportar:
        print(f"  {u:>8.2f} {tp_:>5} {fn_:>5} {fp_:>5} {tn_:>5} {prec:>8.4f} {rec:>8.4f} {f1_:>8.4f}")

auc_avg = roc_auc_score([1]*len(pos_avg) + [0]*len(neg_avg),
                         -np.concatenate([pos_avg, neg_avg]))
print(f"\n  AUROC del promedio: {auc_avg:.4f}")
print(f"  Mejor umbral: {mejor_umbral:.2f}  →  F1 = {mejor_f1:.4f}")

# ── Comparación directa ───────────────────────────────────────────────
print(f"\nMultiplicativo vs promedio (ambos calibrados en A_B vs A_Ap):")
print(f"  Multiplicativo F1 (κD=0.56 fijo): {f1_mult:.4f}   AUROC: {auc_mult:.4f}")
print(f"  Promedio F1 (umbral óptimo):     {mejor_f1:.4f}   AUROC: {auc_avg:.4f}")
print(f"  ΔF1 = {f1_mult - mejor_f1:+.4f}")
print(f"  ΔAUROC = {auc_mult - auc_avg:+.4f}")

# ── Diagnóstico adicional: ¿son separables A_B y A_Ap? ────────────────
print(f"\nDistribución de isi_final:")
print(f"  A_B (positivos):   mediana={np.median(pos_final):.4f}  media={pos_final.mean():.4f}  p10={np.percentile(pos_final, 10):.4f}  p90={np.percentile(pos_final, 90):.4f}")
print(f"  A_Ap (negativos):  mediana={np.median(neg_final):.4f}  media={neg_final.mean():.4f}  p10={np.percentile(neg_final, 10):.4f}  p90={np.percentile(neg_final, 90):.4f}")

print(f"\nDistribución de isi_avg:")
print(f"  A_B (positivos):   mediana={np.median(pos_avg):.4f}  media={pos_avg.mean():.4f}  p10={np.percentile(pos_avg, 10):.4f}  p90={np.percentile(pos_avg, 90):.4f}")
print(f"  A_Ap (negativos):  mediana={np.median(neg_avg):.4f}  media={neg_avg.mean():.4f}  p10={np.percentile(neg_avg, 10):.4f}  p90={np.percentile(neg_avg, 90):.4f}")
