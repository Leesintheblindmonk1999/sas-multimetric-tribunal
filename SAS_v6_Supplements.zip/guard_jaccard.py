import json
import re
from pathlib import Path
import numpy as np
from sklearn.metrics import roc_auc_score

KAPPA_D = 0.56

CORPUS_CANDIDATOS = [
    Path(r"C:\ProgramData\benchmark_corpus"),
    Path(r"C:\Users\conno\Downloads\SAS-Semántico\benchmark_corpus"),
    Path(r"C:\Users\conno\Downloads\SAS-Semántico\corpus"),
]
CORPUS = next((p for p in CORPUS_CANDIDATOS if p.exists()), None)
assert CORPUS, "No se encontró el corpus"
print(f"Corpus: {CORPUS}")

MARCADORES = {
    "halueval_dialogue": "Correct response: ",
    "halueval_qa": "Correct answer: ",
    "truthfulqa": "Correct answer: ",
}

# ── Guard: fidelidad del response al source (sin embeddings) ──────────
RE_ANIO = re.compile(r'\b(1[89]\d{2}|20\d{2})\b')
RE_NUMERO = re.compile(r'\b\d+(?:[.,]\d+)?\b')
RE_NOMBRE_PROPIO = re.compile(r'\b[A-Z][a-z]{2,}\b')
RE_NEGACION = re.compile(r'\b(no|not|never|ni|neither|nor|nunca|tampoco)\b', re.IGNORECASE)


def extraer_entidades(texto):
    anios = set(RE_ANIO.findall(texto))
    numeros = set(RE_NUMERO.findall(texto)) - anios
    nombres = set(RE_NOMBRE_PROPIO.findall(texto))
    return {"anios": anios, "numeros": numeros, "nombres": nombres}


def polaridad(texto):
    return bool(RE_NEGACION.search(texto))


def guard_score(source, response):
    """Score en [0,1]: 1 = response probablemente fiel al source."""
    if not response.strip() or not source.strip():
        return 0.0

    # Extracto literal: el response es subcadena del source
    if response.strip() in source:
        return 1.0

    ent_r = extraer_entidades(response)
    ent_s = extraer_entidades(source)

    ents_r = ent_r["anios"] | ent_r["numeros"] | ent_r["nombres"]
    ents_s = ent_s["anios"] | ent_s["numeros"] | ent_s["nombres"]

    if not ents_r:
        return 0.4 if polaridad(source) == polaridad(response) else 0.1

    faltantes = ents_r - ents_s
    if not faltantes:
        score = 1.0
    else:
        frac = len(faltantes) / len(ents_r)
        score = max(0.0, 1.0 - frac)

    if polaridad(source) != polaridad(response):
        score *= 0.5

    return score


def jaccard(a, b):
    sa = set(a.lower().split())
    sb = set(b.lower().split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def extraer_a_prime(texto_a, suite):
    marcador = MARCADORES[suite]
    idx = texto_a.find(marcador)
    if idx == -1:
        return None
    return texto_a[idx + len(marcador):].strip()


# ── Cargar N1 y corpus ────────────────────────────────────────────────
d = json.load(open("reports/pairs_conditions_1800_seed42.json", encoding="utf-8"))
r = d["resultados"]

idx = {}
for x in r:
    idx[(x["suite"], x["id"], x["condicion"])] = x

ids_unicos = sorted(set((x["suite"], x["id"]) for x in r))

filas = []
for suite, pid in ids_unicos:
    ab = idx.get((suite, pid, "A_B"))
    ap = idx.get((suite, pid, "A_Ap"))
    if not ab or not ap:
        continue

    arch_a = CORPUS / suite / f"{pid}_A_clean.txt"
    arch_b = CORPUS / suite / f"{pid}_B_hallucination.txt"
    if not arch_a.exists() or not arch_b.exists():
        continue

    a_texto = arch_a.read_text(encoding="utf-8", errors="replace").strip()
    b_texto = arch_b.read_text(encoding="utf-8", errors="replace").strip()
    a_prime = extraer_a_prime(a_texto, suite)
    if not a_prime:
        continue

    # Guard y jaccard para los dos pares
    g_ab = guard_score(a_texto, b_texto)
    g_ap = guard_score(a_texto, a_prime)
    j_ab = jaccard(a_texto, b_texto)
    j_ap = jaccard(a_texto, a_prime)

    filas.append({
        "suite": suite, "id": pid,
        "isi_final_ab": ab["isi_final"], "isi_final_ap": ap["isi_final"],
        "guard_ab": g_ab, "guard_ap": g_ap,
        "jacc_ab": j_ab, "jacc_ap": j_ap,
    })

print(f"Filas completas: {len(filas)}")

# ── Arrays ────────────────────────────────────────────────────────────
jacc_ab = np.array([f["jacc_ab"] for f in filas])
jacc_ap = np.array([f["jacc_ap"] for f in filas])
isi_ab  = np.array([f["isi_final_ab"] for f in filas])
isi_ap  = np.array([f["isi_final_ap"] for f in filas])
guard_ab = np.array([f["guard_ab"] for f in filas])
guard_ap = np.array([f["guard_ap"] for f in filas])

# Guard aplica como rescue: sube el score cuando detecta fidelidad
jacc_guard_ab = np.maximum(jacc_ab, guard_ab)
jacc_guard_ap = np.maximum(jacc_ap, guard_ap)
isi_guard_ab = np.maximum(isi_ab, guard_ab)
isi_guard_ap = np.maximum(isi_ap, guard_ap)


def metricas(pos_scores, neg_scores, threshold=0.56):
    """Detección = score < threshold."""
    pos = np.array(pos_scores)
    neg = np.array(neg_scores)
    tp = int((pos < threshold).sum())
    fn = int((pos >= threshold).sum())
    fp = int((neg < threshold).sum())
    tn = int((neg >= threshold).sum())
    prec = tp / (tp + fp) if (tp + fp) else 0
    rec = tp / (tp + fn) if (tp + fn) else 0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0
    return tp, fn, fp, tn, prec, rec, f1


def auroc(pos_scores, neg_scores):
    y = [1]*len(pos_scores) + [0]*len(neg_scores)
    s = list(-np.array(pos_scores)) + list(-np.array(neg_scores))
    return roc_auc_score(y, s)


print("\n" + "="*72)
print("COMPARACIÓN 4 MÉTODOS sobre A_B (positivos) vs A_Ap (negativos)")
print("="*72)

for nombre, pos, neg in [
    ("Jaccard solo", jacc_ab, jacc_ap),
    ("Tribunal solo", isi_ab, isi_ap),
    ("Jaccard + guard", jacc_guard_ab, jacc_guard_ap),
    ("Tribunal + guard", isi_guard_ab, isi_guard_ap),
]:
    tp, fn, fp, tn, prec, rec, f1 = metricas(pos, neg)
    auc = auroc(pos, neg)
    print(f"\n{nombre}:")
    print(f"  TP={tp}  FN={fn}  FP={fp}  TN={tn}")
    print(f"  Precision={prec:.4f}  Recall={rec:.4f}  F1={f1:.4f}  AUROC={auc:.4f}")

# Diagnóstico de guard
print(f"\nGuard score (>= 0.56):")
print(f"  A_B:  mediana={np.median(guard_ab):.4f}  media={guard_ab.mean():.4f}  dispara={(guard_ab >= 0.56).sum()}")
print(f"  A_Ap: mediana={np.median(guard_ap):.4f}  media={guard_ap.mean():.4f}  dispara={(guard_ap >= 0.56).sum()}")

# Cuántos A_B son subcadena literal de A
substring_ab = sum(1 for f in filas if f["guard_ab"] == 1.0)
print(f"\nA_B con guard=1.0 (response subcadena de source): {substring_ab}/{len(filas)}")

# Cuántos A_Ap son subcadena
substring_ap = sum(1 for f in filas if f["guard_ap"] == 1.0)
print(f"A_Ap con guard=1.0 (response subcadena de source): {substring_ap}/{len(filas)}")